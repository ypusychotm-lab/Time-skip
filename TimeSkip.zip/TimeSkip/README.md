# Time Skip

Four buttons that move your phone's real clock forward: +30 minutes, +1 hour, +1 day, +1 month.
It uses Shizuku, so no root is needed.

## Build (on a computer)
1. Install Android Studio.
2. File > Open, choose the `TimeSkip` folder.
3. Let Gradle sync (accept any "update plugin" suggestions).
4. Connect your phone (or use Build > Build APK(s)) and install the APK.

## Use (on the phone)
1. Install Shizuku and start it with Wireless debugging.
2. Open Time Skip and tap a button.
3. Tap Allow when Shizuku asks for permission.

The app turns off "Automatic date & time" for you the first time it changes the clock.
To go back to normal, turn "Automatic date & time" on again in Settings.
