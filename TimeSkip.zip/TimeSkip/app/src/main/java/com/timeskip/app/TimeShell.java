package com.timeskip.app;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.Calendar;

import rikka.shizuku.Shizuku;

public class TimeShell {

    public static boolean shizukuReady() {
        try {
            return Shizuku.pingBinder()
                    && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean shizukuRunning() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    private static Process shizukuProcess(String[] cmd) throws Exception {
        Method m = Shizuku.class.getDeclaredMethod("newProcess",
                String[].class, String[].class, String.class);
        m.setAccessible(true);
        return (Process) m.invoke(null, cmd, null, null);
    }

    private static String run(Process p) throws Exception {
        StringBuilder sb = new StringBuilder();
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while ((line = r.readLine()) != null) sb.append(line).append('\n');
        BufferedReader e = new BufferedReader(new InputStreamReader(p.getErrorStream()));
        while ((line = e.readLine()) != null) sb.append(line).append('\n');
        p.waitFor();
        return sb.toString().trim();
    }

    /** Run a shell command through Shizuku, or root if Shizuku is unavailable. */
    public static String exec(String command) {
        if (shizukuReady()) {
            try {
                return run(shizukuProcess(new String[]{"sh", "-c", command}));
            } catch (Throwable t) {
                // fall through to root
            }
        }
        try {
            return run(Runtime.getRuntime().exec(new String[]{"su", "-c", command}));
        } catch (Throwable t) {
            return "ERROR: no Shizuku or root access";
        }
    }

    /** Shift the system clock. unit: Calendar.MINUTE / HOUR_OF_DAY / DAY_OF_MONTH / MONTH. */
    public static String shift(int unit, int amount) {
        Calendar c = Calendar.getInstance();
        c.add(unit, amount);
        long ms = c.getTimeInMillis();
        // Turn off automatic time so the clock does not snap back.
        exec("settings put global auto_time 0");
        String out = exec("cmd alarm set-time " + ms);
        if (out.toLowerCase().contains("error") || out.toLowerCase().contains("exception")
                || out.toLowerCase().contains("unknown")) {
            out = exec("date @" + (ms / 1000));
        }
        return out;
    }
}
