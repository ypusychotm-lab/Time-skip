package com.timeskip.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 96, 48, 48);
        root.setBackgroundColor(Color.parseColor("#121212"));

        TextView title = new TextView(this);
        title.setText("Time Skip");
        title.setTextSize(28);
        title.setTextColor(Color.WHITE);
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(15);
        status.setTextColor(Color.LTGRAY);
        status.setPadding(0, 32, 0, 32);
        root.addView(status);

        root.addView(button("1. Allow floating window", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        }));

        root.addView(button("2. Allow Shizuku (skip if rooted)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (!Shizuku.pingBinder()) {
                        status.setText("Shizuku is not running. Open the Shizuku app and start it first.");
                        return;
                    }
                    Shizuku.requestPermission(100);
                } catch (Throwable t) {
                    status.setText("Shizuku not installed. Install it, start it, then try again.");
                }
            }
        }));

        root.addView(button("3. Start floating panel", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    status.setText("Do step 1 first: allow the floating window.");
                    return;
                }
                Intent i = new Intent(MainActivity.this, FloatService.class);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
                else startService(i);
                refresh();
            }
        }));

        setContentView(root);
        refresh();
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        String s = "Floating window: " + (Settings.canDrawOverlays(this) ? "allowed" : "NOT allowed") + "\n";
        s += "Shizuku: " + (TimeShell.shizukuReady() ? "ready"
                : TimeShell.shizukuRunning() ? "running, permission needed" : "not running") + "\n";
        s += "\nNo Shizuku? Rooted phones work too (grant root when asked).";
        status.setText(s);
    }
}
