package com.timeskip.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FloatService extends Service {

    private WindowManager wm;
    private LinearLayout panel;
    private LinearLayout body;
    private TextView clock;
    private WindowManager.LayoutParams lp;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (clock != null) {
                clock.setText(new SimpleDateFormat("d MMM yyyy  HH:mm:ss", Locale.getDefault())
                        .format(new Date()));
            }
            handler.postDelayed(this, 1000);
        }
    };
    private boolean expanded = true;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForegroundNotification();
        if (panel == null) buildPanel();
        return START_STICKY;
    }

    private void startForegroundNotification() {
        String id = "timeskip";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(id, "Time Skip",
                    NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, id) : new Notification.Builder(this);
        b.setContentTitle("Time Skip is running")
                .setSmallIcon(android.R.drawable.ic_menu_recent_history);
        startForeground(1, b.build());
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private Button btn(final String label, final int unit, final int amount) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setPadding(dp(4), 0, dp(4), 0);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(8));
        g.setColor(amount > 0 ? Color.parseColor("#2E7D32") : Color.parseColor("#C62828"));
        b.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(40), 1f);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(p);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        TimeShell.shift(unit, amount);
                    }
                }).start();
            }
        });
        return b;
    }

    private LinearLayout row(Button... buttons) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        for (Button b : buttons) r.addView(b);
        return r;
    }

    private void buildPanel() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(6), dp(6), dp(6), dp(6));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor(Color.parseColor("#E6202124"));
        panel.setBackground(bg);

        // Header: drag handle + clock + collapse button
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        clock = new TextView(this);
        clock.setTextColor(Color.WHITE);
        clock.setTextSize(12);
        clock.setPadding(dp(6), dp(4), dp(6), dp(4));
        header.addView(clock, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView toggle = new TextView(this);
        toggle.setText("[-]");
        toggle.setTextColor(Color.WHITE);
        toggle.setTextSize(14);
        toggle.setPadding(dp(10), dp(4), dp(10), dp(4));
        header.addView(toggle);

        TextView close = new TextView(this);
        close.setText("[x]");
        close.setTextColor(Color.parseColor("#FF8A80"));
        close.setTextSize(14);
        close.setPadding(dp(10), dp(4), dp(10), dp(4));
        header.addView(close);

        panel.addView(header);

        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.addView(row(btn("+30 min", Calendar.MINUTE, 30), btn("-30 min", Calendar.MINUTE, -30)));
        body.addView(row(btn("+1 hour", Calendar.HOUR_OF_DAY, 1), btn("-1 hour", Calendar.HOUR_OF_DAY, -1)));
        body.addView(row(btn("+1 day", Calendar.DAY_OF_MONTH, 1), btn("-1 day", Calendar.DAY_OF_MONTH, -1)));
        body.addView(row(btn("+1 month", Calendar.MONTH, 1), btn("-1 month", Calendar.MONTH, -1)));
        panel.addView(body);

        toggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expanded = !expanded;
                body.setVisibility(expanded ? View.VISIBLE : View.GONE);
                ((TextView) v).setText(expanded ? "[-]" : "[+]");
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopSelf();
            }
        });

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        lp = new WindowManager.LayoutParams(
                dp(230),
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(20);
        lp.y = dp(120);

        // Drag by touching the header
        header.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = lp.x;
                        startY = lp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = startX + (int) (e.getRawX() - touchX);
                        lp.y = startY + (int) (e.getRawY() - touchY);
                        wm.updateViewLayout(panel, lp);
                        return true;
                }
                return false;
            }
        });

        wm.addView(panel, lp);
        handler.post(tick);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(tick);
        if (panel != null && wm != null) {
            try {
                wm.removeView(panel);
            } catch (Throwable ignored) {
            }
        }
        panel = null;
        super.onDestroy();
    }
}
