package com.example.timeskip

import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private val requestCode = 1001
    private val handler = Handler(Looper.getMainLooper())
    private val clockFormat = SimpleDateFormat("EEE d MMM yyyy\nHH:mm:ss", Locale.getDefault())

    private lateinit var clockText: TextView
    private lateinit var statusText: TextView

    private val binderReceived = Shizuku.OnBinderReceivedListener { runOnUiThread { updateStatus() } }
    private val binderDead = Shizuku.OnBinderDeadListener { runOnUiThread { updateStatus() } }
    private val permissionResult =
        Shizuku.OnRequestPermissionResultListener { code, _ ->
            if (code == requestCode) runOnUiThread { updateStatus() }
        }

    private val ticker = object : Runnable {
        override fun run() {
            clockText.text = clockFormat.format(Date())
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        clockText = findViewById(R.id.clockText)
        statusText = findViewById(R.id.statusText)

        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permissionResult)

        findViewById<Button>(R.id.btn30min).setOnClickListener { skip(Calendar.MINUTE, 30) }
        findViewById<Button>(R.id.btn1hour).setOnClickListener { skip(Calendar.HOUR_OF_DAY, 1) }
        findViewById<Button>(R.id.btn1day).setOnClickListener { skip(Calendar.DAY_OF_MONTH, 1) }
        findViewById<Button>(R.id.btn1month).setOnClickListener { skip(Calendar.MONTH, 1) }
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
        updateStatus()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permissionResult)
    }

    private fun shizukuRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    private fun hasPermission(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    private fun updateStatus() {
        statusText.text = when {
            !shizukuRunning() -> "Shizuku is not running.\nOpen Shizuku and tap Start."
            !hasPermission() -> "Shizuku is running.\nTap any button to grant permission."
            else -> "Ready."
        }
    }

    /** Returns true when we can go ahead and change the clock. */
    private fun ready(): Boolean {
        if (!shizukuRunning()) {
            updateStatus()
            toast("Start Shizuku first")
            return false
        }
        if (!hasPermission()) {
            Shizuku.requestPermission(requestCode)
            return false
        }
        return true
    }

    private fun skip(field: Int, amount: Int) {
        if (!ready()) return

        thread {
            val cal = Calendar.getInstance()
            cal.add(field, amount)
            val millis = cal.timeInMillis

            // Turn off "Automatic date & time" so Android doesn't snap the clock back,
            // then set the new time.
            val result = runShell("settings put global auto_time 0; cmd alarm set-time $millis")

            runOnUiThread {
                if (result.first == 0 && !result.second.contains("Exception", ignoreCase = true)) {
                    toast("Time moved forward")
                } else {
                    toast("Failed: ${result.second.ifBlank { "exit code ${result.first}" }}")
                }
                statusText.text = "Ready."
            }
        }
    }

    /**
     * Runs a shell command with Shizuku's (ADB shell) permissions.
     * Shizuku.newProcess is not public in newer versions, so it is called by reflection.
     */
    private fun runShell(command: String): Pair<Int, String> {
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val out = process.inputStream.bufferedReader().readText()
            val err = process.errorStream.bufferedReader().readText()
            val code = process.waitFor()
            code to (out + err).trim()
        } catch (e: Throwable) {
            -1 to (e.cause?.message ?: e.message ?: "unknown error")
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
