# Time Skip

A floating button that sits over any app or game. Tap it to open four buttons that move
your phone's real clock forward: +30 min, +1 hour, +1 day, +1 month. Uses Shizuku, no root.

## First-time setup (in the app)
1. Start Shizuku (Wireless debugging, then Start).
2. Open Time Skip, tap "1. Allow Shizuku", then Allow.
3. Tap "2. Allow display over apps" and turn the switch on for Time Skip.
4. Tap "3. Start floating button". A small bubble appears.
5. Open your game. Tap the bubble, then a button. Drag the bubble to move it.

The app turns off "Automatic date & time" when it changes the clock.
To go back to normal, turn it back on in Settings.
