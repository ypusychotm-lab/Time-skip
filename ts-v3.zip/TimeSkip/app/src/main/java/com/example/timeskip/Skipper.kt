package com.example.timeskip

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.util.Calendar

/** Moves the system clock forward through Shizuku (ADB shell permissions). */
object Skipper {

    fun shizukuRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    /** Adds [amount] of [field] (Calendar.MINUTE, HOUR_OF_DAY, DAY_OF_MONTH, MONTH) to the current time. */
    fun skip(field: Int, amount: Int): Pair<Int, String> {
        val cal = Calendar.getInstance()
        cal.add(field, amount)
        val millis = cal.timeInMillis
        // Turn off "Automatic date & time" so Android doesn't snap the clock back, then set the time.
        return runShell("settings put global auto_time 0; cmd alarm set-time $millis")
    }

    /** Shizuku.newProcess is not public in newer versions, so it is called by reflection. */
    private fun runShell(command: String): Pair<Int, String> {
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val out = process.inputStream.bufferedReader().readText()
            val err = process.errorStream.bufferedReader().readText()
            val code = process.waitFor()
            code to (out + err).trim()
        } catch (e: Throwable) {
            -1 to (e.cause?.message ?: e.message ?: "unknown error")
        }
    }
}
