package com.example.timeskip

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private val shizukuRequestCode = 1001
    private lateinit var status: TextView

    private val binderReceived = Shizuku.OnBinderReceivedListener { runOnUiThread { updateStatus() } }
    private val binderDead = Shizuku.OnBinderDeadListener { runOnUiThread { updateStatus() } }
    private val permissionResult = Shizuku.OnRequestPermissionResultListener { code, _ ->
        if (code == shizukuRequestCode) runOnUiThread { updateStatus() }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }

        status = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(24))
        }
        layout.addView(status)

        layout.addView(makeButton("1. Allow Shizuku") { requestShizuku() })
        layout.addView(makeButton("2. Allow display over apps") { requestOverlay() })
        layout.addView(makeButton("3. Start floating button") { startOverlay() })
        layout.addView(makeButton("Stop floating button") {
            stopService(Intent(this, OverlayService::class.java))
        })

        setContentView(layout)

        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permissionResult)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 2002)
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permissionResult)
    }

    private fun makeButton(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) }
            setOnClickListener { onClick() }
        }

    private fun updateStatus() {
        val shizuku = if (Skipper.shizukuRunning()) "running" else "NOT running (open Shizuku, tap Start)"
        val perm = if (Skipper.hasPermission()) "allowed" else "not yet"
        val overlay = if (Settings.canDrawOverlays(this)) "allowed" else "not yet"
        status.text = "Shizuku: $shizuku\nShizuku permission: $perm\nDisplay over apps: $overlay"
    }

    private fun requestShizuku() {
        when {
            !Skipper.shizukuRunning() -> toast("Start Shizuku first")
            Skipper.hasPermission() -> toast("Already allowed")
            else -> Shizuku.requestPermission(shizukuRequestCode)
        }
    }

    private fun requestOverlay() {
        if (Settings.canDrawOverlays(this)) {
            toast("Already allowed")
        } else {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
    }

    private fun startOverlay() {
        when {
            !Settings.canDrawOverlays(this) -> toast("Do step 2 first")
            !Skipper.shizukuRunning() -> toast("Start Shizuku first")
            !Skipper.hasPermission() -> toast("Do step 1 first")
            else -> {
                startForegroundService(Intent(this, OverlayService::class.java))
                toast("Floating button started. Open your game.")
            }
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
