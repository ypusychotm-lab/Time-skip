package com.example.timeskip

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import java.util.Calendar
import kotlin.concurrent.thread
import kotlin.math.abs

/** Shows a small draggable bubble over every app. Tap it to open the four skip buttons. */
class OverlayService : Service() {

    private val ui = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var container: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        showOverlay()
    }

    override fun onDestroy() {
        container?.let {
            try {
                windowManager?.removeView(it)
            } catch (e: Exception) {
                // already removed
            }
        }
        container = null
        super.onDestroy()
    }

    private fun startForegroundNotification() {
        val channelId = "timeskip_overlay"
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(channelId, "Time Skip", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Time Skip is running")
            .setContentText("The floating button is on screen")
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setOngoing(true)
            .build()
        startForeground(1, notification)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = dp(200)
        }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        container = root

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setBackgroundColor(0xCC202020.toInt())
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        panel.addView(skipRow("30m", Calendar.MINUTE, 30, panel))
        panel.addView(skipRow("1h", Calendar.HOUR_OF_DAY, 1, panel))
        panel.addView(skipRow("1d", Calendar.DAY_OF_MONTH, 1, panel))
        panel.addView(skipRow("1mo", Calendar.MONTH, 1, panel))
        panel.addView(Button(this).apply {
            text = "Close"
            isAllCaps = false
            setOnClickListener { stopSelf() }
        })

        val bubble = Button(this).apply {
            text = "⏱"
            textSize = 18f
            alpha = 0.85f
            minWidth = 0
            minHeight = 0
            setPadding(0, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        bubble.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        wm.updateViewLayout(root, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        panel.visibility =
                            if (panel.visibility == View.GONE) View.VISIBLE else View.GONE
                    }
                    true
                }
                else -> false
            }
        }

        root.addView(bubble)
        root.addView(panel)
        wm.addView(root, params)
    }

    /** One row with a backward button (-) on the left and a forward button (+) on the right. */
    private fun skipRow(label: String, field: Int, amount: Int, panel: View): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(skipButton("-$label", field, -amount, panel))
            addView(skipButton("+$label", field, amount, panel))
        }

    private fun skipButton(label: String, field: Int, amount: Int, panel: View): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener {
                panel.visibility = View.GONE
                doSkip(label, field, amount)
            }
        }

    private fun doSkip(label: String, field: Int, amount: Int) {
        if (!Skipper.shizukuRunning()) {
            toast("Shizuku is not running")
            return
        }
        if (!Skipper.hasPermission()) {
            toast("Open the Time Skip app and allow Shizuku")
            return
        }
        thread {
            val (code, out) = Skipper.skip(field, amount)
            if (code == 0 && !out.contains("exception", ignoreCase = true)) {
                toast("Skipped $label")
            } else {
                toast("Failed: ${out.ifBlank { "exit code $code" }}")
            }
        }
    }

    private fun toast(message: String) {
        ui.post { Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show() }
    }
}
