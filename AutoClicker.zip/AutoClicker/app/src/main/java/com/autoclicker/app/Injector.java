package com.autoclicker.app;

import android.os.IBinder;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.MotionEvent;

import java.lang.reflect.Method;

import rikka.shizuku.ShizukuBinderWrapper;
import rikka.shizuku.SystemServiceHelper;

/** Fast tap injection straight into Android's input system (needs Shizuku). */
public class Injector {

    public static String lastError = "";
    private static Object im;
    private static Method inject;

    public static boolean init() {
        try {
            try {
                org.lsposed.hiddenapibypass.HiddenApiBypass.addHiddenApiExemptions("L");
            } catch (Throwable ignored) {
            }
            if (!Shell.shizukuReady()) {
                lastError = "Shizuku not ready";
                return false;
            }
            IBinder b = new ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"));
            Class<?> stub = Class.forName("android.hardware.input.IInputManager$Stub");
            im = stub.getMethod("asInterface", IBinder.class).invoke(null, b);
            Class<?> iface = Class.forName("android.hardware.input.IInputManager");
            inject = iface.getMethod("injectInputEvent", InputEvent.class, int.class);
            return true;
        } catch (Throwable t) {
            lastError = String.valueOf(t.getMessage() != null ? t.getMessage() : t.getClass().getSimpleName());
            return false;
        }
    }

    public static void tap(int x, int y) throws Exception {
        long now = SystemClock.uptimeMillis();
        MotionEvent down = MotionEvent.obtain(now, now, MotionEvent.ACTION_DOWN, x, y, 0);
        down.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        inject.invoke(im, down, 0);
        down.recycle();
        MotionEvent up = MotionEvent.obtain(now, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, x, y, 0);
        up.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        inject.invoke(im, up, 0);
        up.recycle();
    }
}
