package com.autoclicker.app;

import java.lang.reflect.Method;

import rikka.shizuku.Shizuku;

public class Shell {

    public static boolean shizukuRunning() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean shizukuReady() {
        try {
            return Shizuku.pingBinder()
                    && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Opens a long-lived shell through Shizuku, or through root if Shizuku is not ready. */
    public static Process open() throws Exception {
        if (shizukuReady()) {
            try {
                Method m = Shizuku.class.getDeclaredMethod("newProcess",
                        String[].class, String[].class, String.class);
                m.setAccessible(true);
                return (Process) m.invoke(null, new String[]{"sh"}, null, null);
            } catch (Throwable t) {
                // fall through to root
            }
        }
        return Runtime.getRuntime().exec("su");
    }
}
