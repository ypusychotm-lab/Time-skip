package com.autoclicker.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;

public class ClickService extends Service {

    private static final int MAX_MS = 5000;

    private WindowManager wm;
    private LinearLayout panel;
    private LinearLayout body;
    private View target;
    private WindowManager.LayoutParams panelLp;
    private WindowManager.LayoutParams targetLp;
    private TextView intervalText;
    private TextView info;
    private Button startBtn;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private volatile boolean running = false;
    private volatile int interval = 100;
    private SeekBar seek;
    private boolean seekFromCode = false;
    private Thread worker;
    private boolean expanded = true;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForegroundNotification();
        if (panel == null) build();
        return START_STICKY;
    }

    private void startForegroundNotification() {
        String id = "autoclicker";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(id, "Auto Clicker",
                    NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, id) : new Notification.Builder(this);
        b.setContentTitle("Auto Clicker is running")
                .setSmallIcon(android.R.drawable.ic_media_play);
        startForeground(1, b.build());
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private Button button(String label, String color) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(8));
        g.setColor(Color.parseColor(color));
        b.setBackground(g);
        return b;
    }

    private void setButtonColor(Button b, String color) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(8));
        g.setColor(Color.parseColor(color));
        b.setBackground(g);
    }

    private void build() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        // ---- Target circle (drag it to where you want to tap) ----
        target = new View(this);
        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setColor(Color.parseColor("#55FF1744"));
        ring.setStroke(dp(3), Color.parseColor("#FF1744"));
        target.setBackground(ring);
        targetLp = new WindowManager.LayoutParams(dp(56), dp(56), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        targetLp.gravity = Gravity.TOP | Gravity.START;
        targetLp.x = getResources().getDisplayMetrics().widthPixels / 2 - dp(28);
        targetLp.y = getResources().getDisplayMetrics().heightPixels / 2 - dp(28);
        target.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = targetLp.x;
                        startY = targetLp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        targetLp.x = startX + (int) (e.getRawX() - touchX);
                        targetLp.y = startY + (int) (e.getRawY() - touchY);
                        wm.updateViewLayout(target, targetLp);
                        return true;
                }
                return false;
            }
        });

        // ---- Control panel ----
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(6), dp(6), dp(6), dp(6));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor(Color.parseColor("#E6202124"));
        panel.setBackground(bg);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("Auto Clicker (drag me)");
        title.setTextColor(Color.WHITE);
        title.setTextSize(12);
        title.setPadding(dp(6), dp(4), dp(6), dp(4));
        header.addView(title, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        final TextView toggle = new TextView(this);
        toggle.setText("[-]");
        toggle.setTextColor(Color.WHITE);
        toggle.setTextSize(14);
        toggle.setPadding(dp(10), dp(4), dp(10), dp(4));
        header.addView(toggle);

        TextView close = new TextView(this);
        close.setText("[x]");
        close.setTextColor(Color.parseColor("#FF8A80"));
        close.setTextSize(14);
        close.setPadding(dp(10), dp(4), dp(10), dp(4));
        header.addView(close);
        panel.addView(header);

        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);

        // Interval row: [-]  Every 100 ms  [+]
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        Button minus = button("-", "#455A64");
        Button plus = button("+", "#455A64");
        intervalText = new TextView(this);
        intervalText.setTextColor(Color.WHITE);
        intervalText.setTextSize(13);
        intervalText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(48), dp(40));
        bp.setMargins(dp(3), dp(3), dp(3), dp(3));
        row.addView(minus, bp);
        row.addView(intervalText, new LinearLayout.LayoutParams(0, dp(40), 1f));
        row.addView(plus, bp);
        body.addView(row);

        seek = new SeekBar(this);
        seek.setMax(1000);
        LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(32));
        body.addView(seek, kp);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (seekFromCode) return;
                int ms = (int) Math.round(Math.pow(MAX_MS, progress / 1000.0));
                interval = Math.max(1, Math.min(MAX_MS, ms));
                updateIntervalText();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });

        startBtn = button("Start", "#2E7D32");
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(46));
        sp.setMargins(dp(3), dp(3), dp(3), dp(3));
        body.addView(startBtn, sp);

        info = new TextView(this);
        info.setTextColor(Color.LTGRAY);
        info.setTextSize(11);
        info.setPadding(dp(6), dp(2), dp(6), dp(2));
        info.setText("Drag the red circle onto what you want to tap, then Start. Slider: 1 ms to 5 s.");
        body.addView(info);
        panel.addView(body);

        syncSeek();
        updateIntervalText();

        minus.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { changeInterval(-1); }
        });
        plus.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { changeInterval(1); }
        });
        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (running) stopClicking(); else startClicking();
            }
        });
        toggle.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                expanded = !expanded;
                body.setVisibility(expanded ? View.VISIBLE : View.GONE);
                toggle.setText(expanded ? "[-]" : "[+]");
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { stopSelf(); }
        });

        panelLp = new WindowManager.LayoutParams(dp(230),
                WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.x = dp(20);
        panelLp.y = dp(80);

        header.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = panelLp.x;
                        startY = panelLp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.x = startX + (int) (e.getRawX() - touchX);
                        panelLp.y = startY + (int) (e.getRawY() - touchY);
                        wm.updateViewLayout(panel, panelLp);
                        return true;
                }
                return false;
            }
        });

        wm.addView(target, targetLp);
        wm.addView(panel, panelLp);
    }

    private void changeInterval(int dir) {
        int ms = interval;
        int step = ms < 20 ? 1 : ms < 100 ? 5 : ms < 500 ? 25 : ms < 2000 ? 100 : 500;
        if (dir < 0 && ms - step < 1) ms = 1;
        else ms = ms + dir * step;
        interval = Math.max(1, Math.min(MAX_MS, ms));
        syncSeek();
        updateIntervalText();
    }

    private void syncSeek() {
        seekFromCode = true;
        seek.setProgress((int) Math.round(Math.log(interval) / Math.log(MAX_MS) * 1000));
        seekFromCode = false;
    }

    private void updateIntervalText() {
        int ms = interval;
        intervalText.setText(ms >= 1000 ? "Every " + (ms / 1000f) + " s" : "Every " + ms + " ms");
    }

    private void setTargetTouchable(boolean touchable) {
        if (touchable) {
            targetLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        } else {
            targetLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        }
        try {
            wm.updateViewLayout(target, targetLp);
        } catch (Throwable ignored) {
        }
    }

    private void startClicking() {
        int[] loc = new int[2];
        target.getLocationOnScreen(loc);
        final int x = loc[0] + target.getWidth() / 2;
        final int y = loc[1] + target.getHeight() / 2;

        // Let the tap pass through the red circle instead of hitting it.
        setTargetTouchable(false);
        running = true;
        startBtn.setText("Stop");
        setButtonColor(startBtn, "#C62828");
        info.setText("Clicking at " + x + ", " + y + "...");

        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                Process p = null;
                OutputStream os = null;
                BufferedReader in = null;
                String error = null;
                long count = 0;
                long lastUi = 0;
                boolean fast = Injector.init();
                final String modeMsg = fast ? "Fast mode" : "Slow mode (fast failed: " + Injector.lastError + ")";
                handler.post(new Runnable() {
                    @Override public void run() { if (running) info.setText(modeMsg); }
                });
                String cmd = "input tap " + x + " " + y + " 2>&1; echo done\n";
                try {
                    while (running) {
                        long t0 = SystemClock.uptimeMillis();
                        if (fast) {
                            try {
                                Injector.tap(x, y);
                            } catch (Throwable t) {
                                fast = false;
                                Injector.lastError = String.valueOf(t.getCause() != null ? t.getCause() : t);
                                final String m = "Slow mode (fast failed: " + Injector.lastError + ")";
                                handler.post(new Runnable() {
                                    @Override public void run() { if (running) info.setText(m); }
                                });
                                continue;
                            }
                        } else {
                            if (p == null) {
                                p = Shell.open();
                                os = p.getOutputStream();
                                in = new BufferedReader(new InputStreamReader(p.getInputStream()));
                            }
                            os.write(cmd.getBytes());
                            os.flush();
                            // Wait until this tap has finished so taps never pile up.
                            String line;
                            while ((line = in.readLine()) != null && !line.equals("done")) {
                                // ignore other output
                            }
                            if (line == null) {
                                error = "No Shizuku or root access.";
                                break;
                            }
                        }
                        count++;
                        long now = SystemClock.uptimeMillis();
                        if (now - lastUi > 200) {
                            lastUi = now;
                            final long c = count;
                            final String mode = fast ? "Fast" : "Slow";
                            handler.post(new Runnable() {
                                @Override public void run() {
                                    if (running) info.setText(mode + " mode. Taps: " + c);
                                }
                            });
                        }
                        long wait = interval - (SystemClock.uptimeMillis() - t0);
                        if (wait > 0) Thread.sleep(wait);
                    }
                } catch (InterruptedException ignored) {
                } catch (Throwable t) {
                    error = "Error: " + t.getMessage();
                } finally {
                    if (p != null) p.destroy();
                }
                final String err = error;
                final long total = count;
                handler.post(new Runnable() {
                    @Override public void run() {
                        resetUi(err != null ? err : "Stopped. Total taps: " + total);
                    }
                });
            }
        });
        worker.start();
    }

    private void stopClicking() {
        running = false;
        if (worker != null) worker.interrupt();
    }

    private void resetUi(String message) {
        running = false;
        if (startBtn == null || target == null) return;
        startBtn.setText("Start");
        setButtonColor(startBtn, "#2E7D32");
        info.setText(message);
        setTargetTouchable(true);
    }

    @Override
    public void onDestroy() {
        running = false;
        if (worker != null) worker.interrupt();
        try { if (panel != null) wm.removeView(panel); } catch (Throwable ignored) { }
        try { if (target != null) wm.removeView(target); } catch (Throwable ignored) { }
        panel = null;
        target = null;
        super.onDestroy();
    }
}
